"use client"

import React from "react";
import UserFavProperties from '@/Components/User/UserFavProperties.jsx'
import Meta from "@/Components/Seo/Meta";

const Index = () => {

    return (
        <> 
        <Meta
        title=""
        description=""
        keywords=""
        ogImage=""
        pathName=""
    />
            <UserFavProperties />
        </>
    );
};

export default Index;
