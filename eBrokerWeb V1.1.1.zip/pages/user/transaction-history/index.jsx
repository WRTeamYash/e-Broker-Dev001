"use client"

import React from "react";
import UserTransationHistory from '@/Components/User/UserTransationHistory.jsx'
import Meta from "@/Components/Seo/Meta";

const Index = () => {

    return (
        <> 
        <Meta
        title=""
        description=""
        keywords=""
        ogImage=""
        pathName=""
    />
            <UserTransationHistory />
        </>
    );
};

export default Index;
