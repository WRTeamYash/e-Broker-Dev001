"use client"

import React from "react";
import UserDashboard from '@/Components/User/UserDashboard.jsx'
import Meta from "@/Components/Seo/Meta";

const Index = () => {

    return (
        <>
            <Meta
                title=""
                description=""
                keywords=""
                ogImage=""
                pathName=""
            />
            <UserDashboard />
        </>
    );
};

export default Index;
