import React from "react";
import Layout from "@/Components/Layout/Layout";
import AllCategories from "@/Components/AllCategories/AllCategories";


const Index = () => {
   

    return (
        <Layout>
          <AllCategories />
        </Layout>
    );
};

export default Index;
