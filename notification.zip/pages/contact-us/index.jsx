import React from "react";
import Layout from "@/Components/Layout/Layout";
import ContactUS from "@/Components/ContactUs/ContactUS";

const Index = () => {


    return (
        <Layout>
            <ContactUS />
        </Layout>
    );
};

export default Index;
