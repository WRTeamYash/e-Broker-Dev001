import React from "react";
import Layout from "@/Components/Layout/Layout";
import FeaturedProperty from "@/Components/FeaturedProperty/FeaturedProperty";


const Index = () => {


    return (
        <>
            <Layout>
                <FeaturedProperty />
            </Layout>
        </>
    );
};

export default Index;
