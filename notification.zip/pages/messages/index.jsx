
import React from 'react'
import Layout from "@/Components/Layout/Layout";
import Messages from '@/Components/Messages/Messages';

const Index = () => {
  return (
    <Layout>
      <Messages />
    </Layout>
  )
}

export default Index
