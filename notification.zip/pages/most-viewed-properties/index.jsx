import React from "react";
import Layout from "@/Components/Layout/Layout";
import MostViewProperties from "@/Components/MostViewProperties/MostViewProperties";


const Index = () => {

    return (
        <Layout>
            <MostViewProperties />
        </Layout>
    );
};

export default Index;