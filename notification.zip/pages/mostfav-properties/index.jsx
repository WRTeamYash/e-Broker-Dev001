import React from "react";
import Layout from "@/Components/Layout/Layout";
import MostFavPrioperties from "@/Components/MostFavProperties/MostFavPrioperties";


const Index = () => {
   

    return (
        <Layout>
          <MostFavPrioperties />
        </Layout>
    );
};

export default Index;
