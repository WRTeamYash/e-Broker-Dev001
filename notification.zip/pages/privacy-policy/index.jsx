import React from "react";
import Layout from "@/Components/Layout/Layout";
import PrivacyPolicy from "@/Components/PrivacyPolicy/PrivacyPolicy";


const Index = () => {

    return (
        <Layout>
            <PrivacyPolicy />
        </Layout>
    );
};

export default Index;
