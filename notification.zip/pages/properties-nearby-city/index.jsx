import React from "react";
import Layout from "@/Components/Layout/Layout";
import NearBycity from "@/Components/NearByCity/NearBycity";

const Index = () => {


    return (
        <Layout>
            <NearBycity />
        </Layout>
    );
};

export default Index;
