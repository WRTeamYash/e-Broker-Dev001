import React from "react";
import Layout from "@/Components/Layout/Layout";
import AllProperties from "@/Components/Properties/AllProperties";


const Index = () => {

    return (
        <Layout>
            <AllProperties />
        </Layout>
    );
};

export default Index;
