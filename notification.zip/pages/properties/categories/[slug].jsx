import React from "react";
import Layout from "@/Components/Layout/Layout";
import Categories from "@/Components/Properties/Categories";

const Index = () => {

    return (
        <Layout>
            <Categories />
        </Layout>
    );
};

export default Index;