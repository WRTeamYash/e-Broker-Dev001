import React from "react";
import Layout from "@/Components/Layout/Layout";
import City from "@/Components/Properties/City";


const Index = () => {

    return (
        <Layout>
            <City />
        </Layout>
    );
};

export default Index;
