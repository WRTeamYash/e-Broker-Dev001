import React, { useEffect, useState } from "react";
import Layout from "@/Components/Layout/Layout";
import SearchPage from "@/Components/SearchPage/SearchPage";

const Index = () => {



    return (
        <Layout>
            <SearchPage />
        </Layout>
    );
};

export default Index;
