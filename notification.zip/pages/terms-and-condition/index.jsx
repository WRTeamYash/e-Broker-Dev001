import React from "react";
import Layout from "@/Components/Layout/Layout";
import TermsAndCondition from "@/Components/TermsAndCondition/TermsAndCondition";


const Index = () => {
    
    return (
        <Layout>
          <TermsAndCondition />
        </Layout>
    );
};

export default Index;
