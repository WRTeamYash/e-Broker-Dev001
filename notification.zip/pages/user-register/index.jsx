import React from "react";
import Layout from "@/Components/Layout/Layout";
import UserRegister from "@/Components/UserRegister/UserRegister";

const Index = () => {


    return (
        <Layout>
           <UserRegister />
        </Layout>
    );
};

export default Index;
