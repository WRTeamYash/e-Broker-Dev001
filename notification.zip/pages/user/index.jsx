import React from "react";
import DashboardContent from "../../src/Components/DashboardContent/DashboardContent.jsx";

const index = () => {
    return (
        <>
            <DashboardContent />
        </>
    );
};

export default index;