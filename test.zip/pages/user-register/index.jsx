import React from "react";
import UserRegister from "@/Components/UserRegister/UserRegister";

const Index = () => {


    return (
           <UserRegister />
    );
};

export default Index;
