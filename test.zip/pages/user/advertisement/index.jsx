"use client"
import Meta from '@/Components/Seo/Meta'
import React from 'react'
import UserAdvertisement from '@/Components/User/UserAdvertisement.jsx'


const Index = () => {
    return (
        <>
            <Meta
                title=""
                description=""
                keywords=""
                ogImage=""
                pathName=""
            />
            <UserAdvertisement />
        </>
    )
}

export default Index
