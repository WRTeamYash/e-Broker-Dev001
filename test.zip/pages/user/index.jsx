"use client"
import React from "react";
import DashboardContent from "../../src/Components/DashboardContent/DashboardContent.jsx";

const Index = () => {
    return (
        <>
            <DashboardContent />
        </>
    );
};

export default Index;