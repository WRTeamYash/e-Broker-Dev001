"use client"

import React from "react";
import IntrestedUsers from '@/Components/User/IntrestedUsers.jsx'
import Meta from "@/Components/Seo/Meta";

const Index = () => {

    return (
        <> 
        <Meta
        title=""
        description=""
        keywords=""
        ogImage=""
        pathName=""
    />
            <IntrestedUsers />
        </>
    );
};

export default Index;
