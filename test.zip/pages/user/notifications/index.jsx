"use client"

import React from "react";
import UserNotification from '@/Components/User/UserNotification.jsx'
import Meta from "@/Components/Seo/Meta";

const Index = () => {

    return (
        <> 
        <Meta
        title=""
        description=""
        keywords=""
        ogImage=""
        pathName=""
    />
            <UserNotification />
        </>
    );
};

export default Index;
