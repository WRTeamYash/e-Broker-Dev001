"use client"
import React from "react";
import UserProfile from '@/Components/User/UserProfile.jsx'
import Meta from "@/Components/Seo/Meta";

const Index = () => {

    return (
        <> 
        <Meta
        title=""
        description=""
        keywords=""
        ogImage=""
        pathName=""
    />
            <UserProfile />
        </>
    );
};

export default Index;
