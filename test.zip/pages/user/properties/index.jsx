"use client"

import React from "react";
import UserAddProperty from '@/Components/User/UserAddProperty.jsx'
import Meta from "@/Components/Seo/Meta";

const Index = () => {

    return (
        <>
            <Meta
                title=""
                description=""
                keywords=""
                ogImage=""
                pathName=""
            />
            <UserAddProperty />
        </>
    );
};

export default Index;
