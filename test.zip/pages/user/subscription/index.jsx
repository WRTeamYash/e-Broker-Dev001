"use client"

import React from "react";
import UserSubScription from '@/Components/User/UserSubScription.jsx'
import Meta from "@/Components/Seo/Meta";

const Index = () => {

    return (
        <> 
        <Meta
        title=""
        description=""
        keywords=""
        ogImage=""
        pathName=""
    />
            <UserSubScription />
        </>
    );
};

export default Index;
