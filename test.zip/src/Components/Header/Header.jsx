
import React from 'react'
import Nav from '../Navbar/Navbar.jsx'

const Header = () => {

  return (
    <div>
      <Nav />
    </div>
  )
}

export default Header
